let xmlhttp = new XMLHttpRequest();
let file = "json.txt";
let url = "http://localhost:8000/getallrecords";
//
async function getData(){
  const response = await fetch(file);
	const json = await response.json();
  console.log(json);
};
//
getData();
//
